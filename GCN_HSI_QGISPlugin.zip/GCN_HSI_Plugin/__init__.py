from qgis.core import QgsApplication
from .gcn_hsi_provider import GCNHSIProvider


class GCNHSIPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.provider = None

    def initGui(self):
        self.provider = GCNHSIProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def unload(self):
        if self.provider is not None:
            QgsApplication.processingRegistry().removeProvider(self.provider)


def classFactory(iface):
    return GCNHSIPlugin(iface)
