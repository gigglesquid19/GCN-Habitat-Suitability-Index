from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
import os
from .gcn_habitat_suitability_algorithm import GCNHabitatSuitabilityAlgorithm


class GCNHSIProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(GCNHabitatSuitabilityAlgorithm())

    def id(self):
        return "gcnhsi"

    def name(self):
        return "GCN-HSI"

    def longName(self):
        return "GCN Habitat Suitability Index Tools"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'Icons', 'GCN.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QIcon()

    def supportsNonFileBasedOutput(self):
        return True

    def createInstance(self):
        return GCNHSIProvider()
