from qgis.core import (
    QgsProcessing, QgsProcessingAlgorithm, QgsProcessingException,
    QgsProcessingParameterFeatureSource, QgsProcessingParameterEnum,
    QgsProcessingParameterNumber, QgsProcessingParameterField,
    QgsProcessingParameterMatrix, QgsProcessingParameterVectorDestination,
    QgsFeature, QgsFields, QgsField, QgsWkbTypes, QgsFeatureSink,
    QgsCoordinateTransform, QgsCoordinateReferenceSystem, QgsProcessingUtils,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsFillSymbol,
    QgsGeometry, QgsPointXY,
)

# ---------------------------------------------------------------------------
# QGIS 3.x / 4.0 API compatibility shims
# ---------------------------------------------------------------------------
try:
    _FIELD_STRING   = QgsProcessingParameterField.DataType.String
except AttributeError:
    _FIELD_STRING   = QgsProcessingParameterField.String

try:
    _FAST_INSERT    = QgsFeatureSink.SinkFlag.FastInsert
except AttributeError:
    _FAST_INSERT    = QgsFeatureSink.FastInsert

from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QIcon
import os
import math
import json
import urllib.request
import urllib.parse

# ============================================================================
# CONSTANTS
# ============================================================================
POND_SEARCH_RADIUS       = 1000
TERRESTRIAL_BUFFER       = 250
NE_ARCGIS_ORG_URL        = "https://services.arcgis.com/JJzESW51TqeY9uat/arcgis/rest/services"
GCN_IRZ_SERVICE_PREFIX   = "GCN_Risk_Zones_"
JRC_GSW_URL              = "http://global-surface-water.appspot.com/details"
JRC_MIN_RELIABLE_AREA_M2 = 900

# Compactness threshold for road identification: 4*pi*area/perimeter^2
# A perfect circle = 1.0; squares ~0.785; roads are typically < 0.05
ROAD_COMPACTNESS_THRESHOLD = 0.05
ROAD_HABITAT_TYPE = "developed land; sealed surface"


class GCNHabitatSuitabilityAlgorithm(QgsProcessingAlgorithm):
    """Semi-automated GCN HSI calculator based on Oldham et al. (2000).
    Accepts 1-10 candidate pond polygons; outputs a layer with per-pond HSI scores."""

    ASSESSMENT_MODE = "ASSESSMENT_MODE"
    CANDIDATE_POND  = "CANDIDATE_POND"
    EXISTING_PONDS  = "EXISTING_PONDS"
    TERR_HABITATS   = "TERR_HABITATS"
    HABITAT_FIELD   = "HABITAT_FIELD"
    GCN_RISK_ZONE   = "GCN_RISK_ZONE"
    POND_PERMANENCE = "POND_PERMANENCE"
    SHORELINE_SHADE = "SHORELINE_SHADE"
    PER_POND_VALUES = "PER_POND_VALUES"
    WATERFOWL       = "WATERFOWL"
    FISH            = "FISH"
    WATER_QUALITY   = "WATER_QUALITY"
    MACROPHYTE      = "MACROPHYTE"
    OUTPUT          = "OUTPUT"

    _ASSESSMENT_OPTIONS = ["Remote Assessment", "Full HSI Assessment"]
    _RISK_ZONE_OPTIONS  = ["(auto-detect)", "Green", "Amber", "Red"]
    _PERMANENCE_OPTIONS = ["(auto-detect)", "Never Dries", "Rarely Dries", "Sometimes Dries", "Dries Annually"]
    _WATERFOWL_OPTIONS  = ["Absent", "Minor", "Major"]
    _FISH_OPTIONS       = ["Absent", "Possible", "Minor", "Major"]
    _WQ_OPTIONS         = ["Good", "Moderate", "Poor", "Bad"]

    def name(self):        return "gcn_habitat_suitability"
    def displayName(self): return "GCN Habitat Suitability Index"
    def group(self):        return "Ecology Tools"
    def groupId(self):      return "ecologytools"

    def icon(self):
        icon_path = os.path.join(os.path.dirname(__file__), 'Icons', 'GCN.png')
        if os.path.exists(icon_path):
            return QIcon(icon_path)
        return QIcon()

    def shortHelpString(self):
        return (
            "<h3>GCN Habitat Suitability Index</h3>"
            "<p>Based on <b>Oldham et al. (2000)</b>. Accepts 1-10 candidate pond polygons.</p>"
            "<p><b>Remote Assessment</b>: 6/10 variables, no site visit required.</p>"
            "<p><b>Full HSI Assessment</b>: all 10 variables including site-visit data.</p>"
            "<p>GCN Risk Zone and Pond Permanence can be auto-detected from national datasets "
            "or overridden manually. Ponds &lt;900m&sup2; use a default permanence value.</p>"
            "<p><b>Per-Pond Values</b>: OID | Shade% | Permanence Override | Risk Zone Override. "
            "Leave override columns blank to use auto-detected values.</p>"
        )

    def initAlgorithm(self, config=None):
        self.addParameter(QgsProcessingParameterEnum(
            self.ASSESSMENT_MODE, "Assessment Mode",
            options=self._ASSESSMENT_OPTIONS, defaultValue=0,
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.CANDIDATE_POND, "Candidate Pond(s) — 1-10 polygons",
            [QgsProcessing.TypeVectorPolygon],
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.EXISTING_PONDS, "Existing Ponds (within 1km)",
            [QgsProcessing.TypeVectorPolygon],
        ))
        self.addParameter(QgsProcessingParameterFeatureSource(
            self.TERR_HABITATS, "Terrestrial Habitats (within 250m)",
            [QgsProcessing.TypeVectorPolygon],
        ))
        self.addParameter(QgsProcessingParameterField(
            self.HABITAT_FIELD, "Habitat Type Field",
            parentLayerParameterName=self.TERR_HABITATS,
            type=_FIELD_STRING,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.GCN_RISK_ZONE, "GCN Risk Zone default",
            options=self._RISK_ZONE_OPTIONS, defaultValue=0, optional=True,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.POND_PERMANENCE, "Pond Permanence default",
            options=self._PERMANENCE_OPTIONS, defaultValue=0, optional=True,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.SHORELINE_SHADE, "Shoreline Shade % (global default)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=0.0, minValue=0.0, maxValue=100.0, optional=True,
        ))
        self.addParameter(QgsProcessingParameterMatrix(
            self.PER_POND_VALUES,
            "Per-Pond Values (OID | Shade % | Permanence Override | Risk Zone Override)",
            numberRows=0, hasFixedNumberRows=False,
            headers=["Pond OID", "Shade (%)", "Permanence Override", "Risk Zone Override"],
            defaultValue=None, optional=True,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.WATERFOWL, "Waterfowl Presence (Full HSI only)",
            options=self._WATERFOWL_OPTIONS, defaultValue=None, optional=True,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.FISH, "Fish Presence (Full HSI only)",
            options=self._FISH_OPTIONS, defaultValue=None, optional=True,
        ))
        self.addParameter(QgsProcessingParameterEnum(
            self.WATER_QUALITY, "Water Quality (Full HSI only)",
            options=self._WQ_OPTIONS, defaultValue=None, optional=True,
        ))
        self.addParameter(QgsProcessingParameterNumber(
            self.MACROPHYTE, "Macrophyte Cover % (Full HSI only)",
            type=QgsProcessingParameterNumber.Double,
            defaultValue=None, minValue=0.0, maxValue=100.0, optional=True,
        ))
        self.addParameter(QgsProcessingParameterVectorDestination(
            self.OUTPUT, "Output HSI Layer",
            type=QgsProcessing.TypeVectorPolygon,
        ))

    # ------------------------------------------------------------------
    # Execution
    # ------------------------------------------------------------------
    def processAlgorithm(self, parameters, context, feedback):
        self._feedback = feedback
        self._context  = context

        mode_idx        = self.parameterAsEnum(parameters, self.ASSESSMENT_MODE, context)
        assessment_mode = self._ASSESSMENT_OPTIONS[mode_idx]
        full_assessment = assessment_mode == "Full HSI Assessment"

        candidate_source = self.parameterAsSource(parameters, self.CANDIDATE_POND,   context)
        existing_source  = self.parameterAsSource(parameters, self.EXISTING_PONDS,   context)
        terr_source      = self.parameterAsSource(parameters, self.TERR_HABITATS,    context)
        habitat_field    = self.parameterAsString(parameters, self.HABITAT_FIELD,    context)

        risk_idx  = self.parameterAsEnum(parameters, self.GCN_RISK_ZONE,   context)
        perm_idx  = self.parameterAsEnum(parameters, self.POND_PERMANENCE,  context)
        gcn_risk_zone_default   = self._RISK_ZONE_OPTIONS[risk_idx]   if risk_idx  > 0 else None
        pond_permanence_default = self._PERMANENCE_OPTIONS[perm_idx]  if perm_idx  > 0 else None

        shade_val = parameters.get(self.SHORELINE_SHADE)
        shade_default = self.parameterAsDouble(parameters, self.SHORELINE_SHADE, context) \
                        if shade_val is not None else None

        wf_idx   = self.parameterAsEnum(parameters, self.WATERFOWL,     context) if full_assessment else -1
        fish_idx = self.parameterAsEnum(parameters, self.FISH,          context) if full_assessment else -1
        wq_idx   = self.parameterAsEnum(parameters, self.WATER_QUALITY, context) if full_assessment else -1
        mac_raw  = parameters.get(self.MACROPHYTE)
        waterfowl_presence = self._WATERFOWL_OPTIONS[wf_idx]  if (full_assessment and wf_idx  >= 0) else None
        fish_presence      = self._FISH_OPTIONS[fish_idx]      if (full_assessment and fish_idx >= 0) else None
        water_quality      = self._WQ_OPTIONS[wq_idx]          if (full_assessment and wq_idx  >= 0) else None
        macrophyte_cover   = self.parameterAsDouble(parameters, self.MACROPHYTE, context) \
                             if (full_assessment and mac_raw is not None) else None

        # Parse per-pond values matrix (flat list: OID, shade, perm, risk, ...)
        per_pond_dict = {}
        raw_matrix = self.parameterAsMatrix(parameters, self.PER_POND_VALUES, context) \
                     if parameters.get(self.PER_POND_VALUES) else []
        for i in range(0, len(raw_matrix), 4):
            chunk = raw_matrix[i:i + 4]
            if len(chunk) < 4:
                break
            try:
                oid   = int(chunk[0])   if chunk[0] not in (None, "") else None
                shade = float(chunk[1]) if chunk[1] not in (None, "") else None
                perm  = str(chunk[2]).strip() or None if chunk[2] not in (None, "") else None
                risk  = str(chunk[3]).strip() or None if chunk[3] not in (None, "") else None
                if oid is not None:
                    per_pond_dict[oid] = {"shade": shade, "permanence": perm, "risk_zone": risk}
            except (ValueError, TypeError):
                pass

        feedback.pushInfo("=" * 60)
        feedback.pushInfo("GCN HABITAT SUITABILITY INDEX — Oldham et al. (2000)")
        feedback.pushInfo(f"Mode: {assessment_mode}")
        feedback.pushInfo("=" * 60)
        if not full_assessment:
            feedback.pushWarning("REMOTE ASSESSMENT — partial results only (6/10 variables)")

        # Step 1: Load candidate ponds
        pond_features = self._load_candidate_ponds(candidate_source)
        n_ponds = len(pond_features)
        feedback.pushInfo(f"Step 1: {n_ponds} candidate pond(s) validated")

        # Cache MAGIC services once for all ponds
        feedback.pushInfo("Step 1b: Fetching GCN Risk Zone service listing...")
        magic_services = None
        try:
            magic_services = self._fetch_magic_services()
            feedback.pushInfo(f"  Found {len(magic_services)} regional services")
        except Exception as e:
            feedback.pushWarning(f"  MAGIC service fetch failed: {e}")

        # Build output fields
        hsi_fields = QgsFields()
        for fname, ftype in [
            ("ORIG_OID",  QVariant.Int),    ("HSI_SCORE", QVariant.Double),
            ("VARS_USED", QVariant.Int),    ("HSI_CLASS", QVariant.String),
            ("ASSESS_MD", QVariant.String), ("SI1_GEOG",  QVariant.Double),
            ("SI2_AREA",  QVariant.Double), ("SI3_PERM",  QVariant.Double),
            ("SI4_TERR",  QVariant.Double), ("SI5_COUNT", QVariant.Double),
            ("SI6_SHADE", QVariant.Double), ("SI7_WFOWL", QVariant.Double),
            ("SI8_FISH",  QVariant.Double), ("SI9_WQ",    QVariant.Double),
            ("SI10_MACP", QVariant.Double),
        ]:
            hsi_fields.append(QgsField(fname, ftype))

        (sink, dest_id) = self.parameterAsSink(
            parameters, self.OUTPUT, context,
            hsi_fields, QgsWkbTypes.Polygon, candidate_source.sourceCrs()
        )
        self._dest_id = dest_id

        source_crs  = candidate_source.sourceCrs()
        NOT_ASSESSED = -9999.0
        small_ponds  = []

        for i, pond in enumerate(pond_features, 1):
            if feedback.isCanceled():
                break

            oid      = pond["oid"]
            area_m2  = pond["area"]
            centroid = pond["centroid"]

            feedback.pushInfo("")
            feedback.pushInfo(f"--- Pond {i}/{n_ponds}  (OID: {oid}  |  Area: {area_m2:.0f} m\u00b2) ---")
            feedback.setProgress(int((i - 1) / n_ponds * 100))

            p = per_pond_dict.get(oid, {})
            shoreline_shade = p.get("shade")      if p.get("shade")      is not None else shade_default
            gcn_risk_zone   = p.get("risk_zone")  or gcn_risk_zone_default
            pond_permanence = p.get("permanence") or pond_permanence_default

            # MAGIC
            feedback.pushInfo("  Step 1b: MAGIC — GCN Risk Zone (SI1)...")
            if magic_services:
                try:
                    magic_zone = self._query_magic_gcn_risk_zone(centroid, source_crs, magic_services)
                    if magic_zone:
                        if not gcn_risk_zone:
                            gcn_risk_zone = magic_zone
                            feedback.pushInfo(f"    MAGIC auto-populated: {gcn_risk_zone}")
                        elif gcn_risk_zone != magic_zone:
                            feedback.pushWarning(f"    MAGIC={magic_zone} but override={gcn_risk_zone}. Using override.")
                        else:
                            feedback.pushInfo(f"    MAGIC confirmed: {gcn_risk_zone}")
                    else:
                        feedback.pushWarning("    MAGIC returned no risk zone.")
                except Exception as e:
                    feedback.pushWarning(f"    MAGIC failed: {e}")

            # JRC
            feedback.pushInfo("  Step 1c: JRC — Pond Permanence (SI3)...")
            if area_m2 < JRC_MIN_RELIABLE_AREA_M2:
                small_ponds.append((oid, area_m2))
                feedback.pushWarning(
                    f"    SKIPPED (OID {oid}): {area_m2:.0f}m\u00b2 < {JRC_MIN_RELIABLE_AREA_M2}m\u00b2 threshold. "
                    "Default permanence (0.5) applied. Manual/Google Earth assessment recommended."
                )
            else:
                try:
                    jrc_perm = self._query_jrc_pond_permanence(centroid, source_crs)
                    if jrc_perm:
                        if not pond_permanence:
                            pond_permanence = jrc_perm
                            feedback.pushInfo(f"    JRC auto-populated: {pond_permanence}")
                        elif pond_permanence != jrc_perm:
                            feedback.pushWarning(f"    JRC={jrc_perm} but override={pond_permanence}. Using override.")
                        else:
                            feedback.pushInfo(f"    JRC confirmed: {pond_permanence}")
                    else:
                        feedback.pushWarning("    JRC returned no water history.")
                except Exception as e:
                    feedback.pushWarning(f"    JRC failed: {e}")

            # Step 2: Terrestrial habitats (done first to capture road barriers for Step 3)
            _, semi_prop, road_geoms = self._assess_terrestrial_habitats(terr_source, centroid, habitat_field)
            feedback.pushInfo(f"  Step 2: Semi-natural within 250m: {semi_prop * 100:.1f}%")

            # Step 3: Existing ponds within 1km (road barriers from Step 2 applied)
            pond_count = self._count_existing_ponds(existing_source, centroid, road_geoms)
            feedback.pushInfo(f"  Step 3: Ponds within 1km (after road exclusion): {pond_count}")

            # Variables used count
            vars_used = 3  # SI2, SI4, SI5 always
            if gcn_risk_zone:   vars_used += 1
            if pond_permanence is not None: vars_used += 1
            if shoreline_shade is not None: vars_used += 1
            if waterfowl_presence: vars_used += 1
            if fish_presence:      vars_used += 1
            if water_quality:      vars_used += 1
            if macrophyte_cover is not None: vars_used += 1

            hsi_scores = self._calculate_hsi_scores(
                area_m2, pond_count, gcn_risk_zone, pond_permanence,
                semi_prop, shoreline_shade, waterfowl_presence,
                fish_presence, water_quality, macrophyte_cover,
            )
            overall = hsi_scores["overall_hsi"]
            feedback.pushInfo(f"  Result: HSI {overall:.3f} ({self._classify_hsi(overall)}) — {vars_used}/10 variables")

            def _safe(key):
                v = hsi_scores.get(key)
                return round(v, 4) if v is not None else NOT_ASSESSED

            out_feat = QgsFeature(hsi_fields)
            out_feat.setGeometry(pond["geom"])
            out_feat["ORIG_OID"]  = oid
            out_feat["HSI_SCORE"] = round(overall, 4)
            out_feat["VARS_USED"] = vars_used
            out_feat["HSI_CLASS"] = self._classify_hsi(overall)
            out_feat["ASSESS_MD"] = assessment_mode
            out_feat["SI1_GEOG"]  = _safe("geographic_location")
            out_feat["SI2_AREA"]  = _safe("pond_area")
            out_feat["SI3_PERM"]  = _safe("permanence")
            out_feat["SI4_TERR"]  = _safe("terrestrial_habitat")
            out_feat["SI5_COUNT"] = _safe("pond_count")
            out_feat["SI6_SHADE"] = _safe("shade")
            out_feat["SI7_WFOWL"] = _safe("waterfowl")
            out_feat["SI8_FISH"]  = _safe("fish")
            out_feat["SI9_WQ"]    = _safe("water_quality")
            out_feat["SI10_MACP"] = _safe("macrophyte")
            sink.addFeature(out_feat, _FAST_INSERT)

        if small_ponds:
            feedback.pushWarning("=" * 60)
            feedback.pushWarning("POND PERMANENCE - MANUAL ASSESSMENT REQUIRED")
            feedback.pushWarning(f"{len(small_ponds)} pond(s) below {JRC_MIN_RELIABLE_AREA_M2}m\u00b2 threshold:")
            for sp_oid, sp_area in small_ponds:
                feedback.pushWarning(f"  OID {sp_oid}  |  {sp_area:.0f}m\u00b2")
            feedback.pushWarning(
                "ACTION: Review inter-year imagery in Google Earth, then re-run "
                "with Permanence Override in Per-Pond Values table."
            )
            feedback.pushWarning("=" * 60)

        feedback.setProgress(100)
        return {self.OUTPUT: dest_id}

    def postProcessAlgorithm(self, context, feedback):
        output_layer = QgsProcessingUtils.mapLayerFromString(self._dest_id, context)
        if output_layer:
            self._apply_traffic_light_symbology(output_layer)
        return {}

    # ------------------------------------------------------------------
    # Spatial helpers
    # ------------------------------------------------------------------
    def _load_candidate_ponds(self, source):
        count = source.featureCount()
        if count < 0:
            count = sum(1 for _ in source.getFeatures())
        if count == 0:
            raise QgsProcessingException("Candidate pond layer contains no features")
        if count > 10:
            raise QgsProcessingException(f"Candidate pond layer has {count} features. Maximum 10 per run.")
        ponds = []
        for feat in source.getFeatures():
            geom = feat.geometry()
            ponds.append({
                "oid":      self._get_oid(feat),
                "geom":     geom,
                "area":     round(geom.area(), 2),
                "centroid": geom.centroid().asPoint(),
            })
        return ponds

    def _get_oid(self, feat):
        for name in ("OBJECTID", "objectid", "FID", "fid", "OID", "oid"):
            if feat.fields().indexOf(name) >= 0:
                return int(feat[name])
        return feat.id()

    def _count_existing_ponds(self, source, centroid, road_geoms=None):
        count = excluded = 0
        for feat in source.getFeatures():
            geom = feat.geometry()
            if not geom:
                continue
            if self._distance(centroid, geom.centroid().asPoint()) > POND_SEARCH_RADIUS:
                continue
            if road_geoms and self._is_blocked_by_road(centroid, geom, road_geoms):
                excluded += 1
                continue
            count += 1
        if excluded > 0:
            self._feedback.pushWarning(
                f"    {excluded} pond(s) excluded from SI5 — located beyond road barrier."
            )
        return count

    def _assess_terrestrial_habitats(self, source, centroid, habitat_field):
        # First pass: separate road barriers from habitat within the 250m buffer
        road_geoms       = []
        habitat_features = []
        for feat in source.getFeatures():
            geom = feat.geometry()
            if not geom:
                continue
            if self._distance(centroid, geom.centroid().asPoint()) > TERRESTRIAL_BUFFER:
                continue
            hab_type = str(feat[habitat_field]) \
                       if feat.fields().indexOf(habitat_field) >= 0 and feat[habitat_field] else ""
            if self._is_road_polygon(geom, hab_type):
                road_geoms.append(geom)
            else:
                habitat_features.append((geom, hab_type))

        if road_geoms:
            self._feedback.pushInfo(
                f"    Road barrier(s) detected within 250m: {len(road_geoms)} polygon(s). "
                "Habitats on the far side will be excluded from SI4."
            )

        # Second pass: score habitats, skipping those blocked by a road barrier
        total_area = semi_area = 0.0
        within = excluded = 0
        for geom, hab_type in habitat_features:
            if self._is_blocked_by_road(centroid, geom, road_geoms):
                excluded += 1
                continue
            area = geom.area()
            total_area += area
            within += 1
            if hab_type and self._classify_habitat_type(hab_type):
                semi_area += area

        if excluded > 0:
            self._feedback.pushWarning(
                f"    {excluded} habitat polygon(s) excluded from SI4 \u2014 located beyond road barrier."
            )
        if within == 0:
            self._feedback.pushWarning(
                "No terrestrial habitats within 250m (after road exclusion). SI4 scored as 0.01."
            )
            return 0.0, 0.0, road_geoms
        return total_area, (semi_area / total_area if total_area > 0 else 0.0), road_geoms

    def _is_road_polygon(self, geom, hab_type):
        """Return True if the polygon is a road: Developed Land; Sealed Surface AND elongated.
        Elongation is measured by compactness = 4*pi*area / perimeter^2.
        A road-like polygon has compactness < ROAD_COMPACTNESS_THRESHOLD.
        """
        if ROAD_HABITAT_TYPE not in hab_type.lower():
            return False
        area = geom.area()
        if area <= 0:
            return False
        perimeter = geom.length()  # returns perimeter for polygon geometries in QGIS 3
        if perimeter <= 0:
            return False
        compactness = (4 * math.pi * area) / (perimeter ** 2)
        return compactness < ROAD_COMPACTNESS_THRESHOLD

    def _is_blocked_by_road(self, centroid, habitat_geom, road_geoms):
        """Return True if any road polygon intersects the straight line from pond centroid
        to the habitat polygon centroid, indicating the road acts as a movement barrier.
        """
        if not road_geoms:
            return False
        hab_centroid = habitat_geom.centroid().asPoint()
        line = QgsGeometry.fromPolylineXY([
            QgsPointXY(centroid.x(), centroid.y()),
            QgsPointXY(hab_centroid.x(), hab_centroid.y()),
        ])
        return any(line.intersects(road) for road in road_geoms)

    def _distance(self, pt1, pt2):
        return math.sqrt((pt1.x() - pt2.x()) ** 2 + (pt1.y() - pt2.y()) ** 2)

    def _to_wgs84(self, point, source_crs):
        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        transform = QgsCoordinateTransform(source_crs, wgs84, self._context.transformContext())
        return transform.transform(point)

    # ------------------------------------------------------------------
    # Web service queries
    # ------------------------------------------------------------------
    def _query_jrc_pond_permanence(self, centroid, source_crs):
        pt = self._to_wgs84(centroid, source_crs)
        url = JRC_GSW_URL + "?" + urllib.parse.urlencode(
            {"lat": round(pt.y(), 6), "lon": round(pt.x(), 6)}
        )
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = json.loads(resp.read().decode("utf-8-sig"))
        profile = data.get("monthly_recurrence_profile", {})
        images  = profile.get("images", [])
        obs     = profile.get("observations", [])
        if not images or not obs:
            return None
        values = [obs[i] / images[i] for i in range(12)
                  if i < len(images) and i < len(obs) and images[i] and images[i] > 0]
        if not values:
            return None
        avg = sum(values) / len(values)
        self._feedback.pushInfo(f"  JRC: {len(values)} months, avg recurrence {avg:.0%}")
        if avg >= 0.85: return "Never Dries"
        if avg >= 0.65: return "Rarely Dries"
        if avg >= 0.35: return "Sometimes Dries"
        return "Dries Annually"

    def _fetch_magic_services(self):
        req = urllib.request.Request(
            f"{NE_ARCGIS_ORG_URL}?f=json",
            headers={"User-Agent": "QGIS-GCN-HSI-Tool/1.0"}
        )
        with urllib.request.urlopen(req, timeout=15) as resp:
            listing = json.loads(resp.read().decode("utf-8-sig"))
        return [s["name"] for s in listing.get("services", [])
                if s.get("name", "").startswith(GCN_IRZ_SERVICE_PREFIX)]

    def _query_magic_gcn_risk_zone(self, centroid, source_crs, services):
        if not services:
            return None
        pt = self._to_wgs84(centroid, source_crs)
        spatial_params = urllib.parse.urlencode({
            "geometry": json.dumps({"x": pt.x(), "y": pt.y(), "spatialReference": {"wkid": 4326}}),
            "geometryType": "esriGeometryPoint", "spatialRel": "esriSpatialRelIntersects",
            "outFields": "*", "returnGeometry": "false", "f": "json",
        })
        for svc_name in services:
            url = f"{NE_ARCGIS_ORG_URL}/{svc_name}/FeatureServer/0/query?{spatial_params}"
            req = urllib.request.Request(url, headers={"User-Agent": "QGIS-GCN-HSI-Tool/1.0"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode("utf-8-sig"))
            if "error" in data or not data.get("features"):
                continue
            attrs = data["features"][0].get("attributes", {})
            zone_value = (attrs.get("Risk_Zone") or attrs.get("IRZ_TYPE") or
                          attrs.get("ZONE") or attrs.get("RISK_ZONE") or attrs.get("risk_lvl"))
            if zone_value is None:
                self._feedback.pushWarning(f"  Feature in {svc_name} — field not recognised: {list(attrs.keys())}")
                return None
            self._feedback.pushInfo(f"  Matched region: {svc_name.replace(GCN_IRZ_SERVICE_PREFIX, '')}")
            z = str(zone_value).upper()
            if "HIGH" in z or "RED"   in z: return "Red"
            if "MED"  in z or "AMBER" in z: return "Amber"
            if "LOW"  in z or "GREEN" in z: return "Green"
            self._feedback.pushWarning(f"  Unrecognised zone value '{zone_value}'")
            return None
        return None

    # ------------------------------------------------------------------
    # HSI scoring (ported from ArcGIS version — pure Python)
    # ------------------------------------------------------------------
    def _calculate_hsi_scores(self, pond_area_m2, pond_count, gcn_risk_zone,
                               pond_permanence, semi_natural_proportion, shoreline_shade,
                               waterfowl_presence=None, fish_presence=None,
                               water_quality=None, macrophyte_cover=None):
        s = {}
        s["geographic_location"] = {"Green": 1.0, "Amber": 0.5, "Red": 0.01}.get(gcn_risk_zone, 0.5)
        s["pond_area"]           = self._score_pond_area(pond_area_m2)
        s["permanence"]          = {"Never Dries": 0.9, "Rarely Dries": 1.0,
                                    "Sometimes Dries": 0.5, "Dries Annually": 0.1}.get(pond_permanence, 0.5)
        s["terrestrial_habitat"] = self._score_terrestrial_habitat(semi_natural_proportion)
        s["pond_count"]          = self._score_pond_count(pond_count)
        s["shade"]               = self._score_shade(shoreline_shade) if shoreline_shade is not None else 0.5
        s["waterfowl"]    = {"Absent": 1.0, "Minor": 0.67, "Major": 0.01}.get(waterfowl_presence) if waterfowl_presence else None
        s["fish"]         = {"Absent": 1.0, "Possible": 0.67, "Minor": 0.33, "Major": 0.01}.get(fish_presence) if fish_presence else None
        s["water_quality"]= {"Good": 1.0, "Moderate": 0.67, "Poor": 0.33, "Bad": 0.01}.get(water_quality) if water_quality else None
        s["macrophyte"]   = self._score_macrophyte_cover(macrophyte_cover) if macrophyte_cover is not None else None
        W = {"geographic_location": 1.0, "pond_area": 1.0, "permanence": 1.0,
             "terrestrial_habitat": 1.0, "pond_count": 1.0, "shade": 1.0,
             "waterfowl": 1.5, "fish": 1.5, "water_quality": 1.0, "macrophyte": 1.0}
        product = tw = 0.0
        for key, score in s.items():
            if score is not None and score > 0:
                w = W.get(key, 1.0)
                product = product + w * math.log(score) if tw == 0 else product + w * math.log(score)
                tw += w
        s["overall_hsi"] = math.exp(product / tw) if tw > 0 else 0.0
        return s

    def _score_pond_area(self, a):
        if a <= 0:    return 0.01
        if a > 2000:  return None
        if a <= 500:  return a / 500.0
        if a <= 600:  return 1.0
        return max(1.0 - (a - 600) * 0.0001429, 0.1)

    def _score_terrestrial_habitat(self, p):
        if p > 0.75:  return 1.0
        if p >= 0.25: return 0.67
        if p > 0.0:   return 0.33
        return 0.01

    def _classify_habitat_type(self, habitat_type):
        h = habitat_type.lower().strip()
        UKHAB = {
            "acid grassland": True, "arable and horticulture": False, "bog": True,
            "broadleaved mixed and yew woodland": True, "built-up areas and gardens": False,
            "calcareous grassland": True, "coniferous woodland": True, "dense scrub": True,
            "dwarf shrub heath": True, "fen marsh and swamp": True, "hedgerows": True,
            "neutral grassland": True, "rivers and streams": True,
            "standing open water and canals": True,
        }
        if h in UKHAB:
            return UKHAB[h]
        SEMI = ["woodland", "scrub", "hedgerow", "rough grassland", "unimproved grassland",
                "heath", "bog", "fen", "reedbed", "marsh", "wetland", "brownfield", "ruderal"]
        POOR = ["modified grassland", "improved grassland", "amenity grassland", "amenity grass",
                "arable", "cultivated", "hard standing", "tarmac", "built", "urban", "bare ground",
                "cereal", "non-cereal", "horticulture", "developed land", "sealed surface"]
        for kw in POOR:
            if kw in h: return False
        for kw in SEMI:
            if kw in h: return True
        if self._feedback:
            self._feedback.pushWarning(f"Unrecognised habitat type '{habitat_type}' — treated as poor structure.")
        return False

    def _score_macrophyte_cover(self, pct):
        return 0.3 + (pct / 75.0) * 0.7 if pct <= 75 else 1.0 - ((pct - 75) / 25.0) * 0.2

    def _score_pond_count(self, count):
        if count <= 0: return 0.01
        d = count / math.pi
        if d >= 5:   return 1.0
        if d <= 0.1: return 0.1
        return min(max(0.1 + 0.9 * (math.log10(d) + 1) / (math.log10(5) + 1), 0.1), 1.0)

    def _score_shade(self, pct):
        return 1.0 if pct <= 60 else max(1.0 - (pct - 60) * 0.02, 0.2)

    def _classify_hsi(self, score):
        if score >= 0.68: return "High"
        if score >= 0.34: return "Moderate"
        return "Low"

    def _apply_traffic_light_symbology(self, layer):
        categories = [
            QgsRendererCategory("High",     QgsFillSymbol.createSimple({"color": "#00B050", "outline_color": "#005C29"}), "High"),
            QgsRendererCategory("Moderate", QgsFillSymbol.createSimple({"color": "#FFA500", "outline_color": "#7F5200"}), "Moderate"),
            QgsRendererCategory("Low",      QgsFillSymbol.createSimple({"color": "#FF0000", "outline_color": "#800000"}), "Low"),
        ]
        layer.setRenderer(QgsCategorizedSymbolRenderer("HSI_CLASS", categories))
        layer.triggerRepaint()

    def createInstance(self):
        return GCNHabitatSuitabilityAlgorithm()
